package com.quantum.ampmjobs.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.quantum.ampmjobs.dao.LoginDetailsRepository;
import com.quantum.ampmjobs.dto.MyJsonData;
import com.quantum.ampmjobs.entities.LoginDetails;
import com.quantum.ampmjobs.service.PublicService;
import com.quantum.ampmjobs.utility.ActivityUtilities;

@Service
public class PublicServiceImpl implements PublicService {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private LoginDetailsRepository loginRepo;

	@Override
	public List<MyJsonData> getCommonData(final String param1, final int param2) {
		String sql = "SELECT public.udfun_get_dropdown(?, ?)";
		String res = jdbcTemplate.queryForObject(sql, String.class, param1, param2);

		return res == null ? new ArrayList<>() : ActivityUtilities.convertJsonIntoObject(res, new ArrayList<>());

	}

	@Override
	public LoginDetails findLoginDetailsByMobile(final long mobile) {
		return loginRepo.findLoginDetailsByMobile(mobile);
	}

	@Override
	public LoginDetails findLoginDetailsByEmail(final String email) {
		return loginRepo.findLoginDetailsByEmail(email);
	}

	@Override
	public void updateLoginDetails(final LoginDetails details) {
		loginRepo.save(details);

	}

}
