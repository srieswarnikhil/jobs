package com.quantum.ampmjobs.service;

import java.util.List;

import com.quantum.ampmjobs.dto.MyJsonData;
import com.quantum.ampmjobs.entities.LoginDetails;

public interface PublicService {

	List<MyJsonData> getCommonData(String countryCode, int i);

	LoginDetails findLoginDetailsByMobile(long mobile);

	LoginDetails findLoginDetailsByEmail(String email);

	void updateLoginDetails(LoginDetails details);

}
