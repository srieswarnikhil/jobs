package com.quantum.ampmjobs.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.quantum.ampmjobs.entities.LoginDetails;

public interface LoginDetailsRepository extends JpaRepository<LoginDetails, Long> {

	@Query("SELECT u FROM LoginDetails u WHERE u.phone = :mobileNumber")
	LoginDetails findLoginDetailsByMobile(long mobileNumber);

	@Query("SELECT u FROM LoginDetails u WHERE u.email = :email")
	LoginDetails findLoginDetailsByEmail(String email);

}