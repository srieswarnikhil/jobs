    
// er payment
function checkPayment(){
	debugger;
    var erAddInfo = document.getElementById('erAddInfo').getAttribute('er-data-url');
    location.href=erAddInfo;
	
}
$(document).ready(function() {
    $('#paymentFormId').submit(function(event) {
      event.preventDefault();
      checkPayment();
    });
});