
    // access denied 
 function goToDashboard() {
				var dashboardUrl = document.getElementById('dashboardUrl').getAttribute('user-dashboard-url');
				location.href = dashboardUrl;
			}   			    			    			